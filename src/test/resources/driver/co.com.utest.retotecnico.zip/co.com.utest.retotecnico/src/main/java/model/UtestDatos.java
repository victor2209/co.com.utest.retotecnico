package model;

public class UtestDatos {
    private String strNombre;
    private String strApellido;
    private String strEmail;
    private String strMesNacimiento;
    private String strDiaNacimiento;
    private String strAnoNcimiento;
    private String strCiudad;
    private String strZip;
    private String strPais;

    public String getStrCiudad() {
        return strCiudad;
    }

    public String getStrZip() {
        return strZip;
    }

    public String getStrPais() {
        return strPais;
    }

    public void setStrPais(String strPais) {
        this.strPais = strPais;
    }

    public void setStrZip(String strZip) {
        this.strZip = strZip;
    }

    public void setStrCiudad(String strCiudad) {
        this.strCiudad = strCiudad;
    }

    public String getStrNombre() {
        return strNombre;
    }

    public void setStrNombre(String strNombre) {
        this.strNombre = strNombre;
    }

    public String getStrApellido() {
        return strApellido;
    }

    public void setStrApellido(String strApellido) {
        this.strApellido = strApellido;
    }

    public String getStrMesNacimiento() {
        return strMesNacimiento;
    }

    public void setStrMesNacimiento(String strMesNacimiento) {
        this.strMesNacimiento = strMesNacimiento;
    }

    public String getStrEmail() {
        return strEmail;
    }

    public void setStrEmail(String strEmail) {
        this.strEmail = strEmail;
    }

    public String getStrDiaNacimiento() {
        return strDiaNacimiento;
    }

    public void setStrDiaNacimiento(String strDiaNacimiento) {
        this.strDiaNacimiento = strDiaNacimiento;
    }

    public String getStrAnoNcimiento() {
        return strAnoNcimiento;
    }

    public void setStrAnoNcimiento(String strAnoNcimiento) {
        this.strAnoNcimiento = strAnoNcimiento;
    }
}
