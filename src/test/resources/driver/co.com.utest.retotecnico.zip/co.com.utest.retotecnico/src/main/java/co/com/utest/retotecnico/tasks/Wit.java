package co.com.utest.retotecnico.tasks;

import net.serenitybdd.screenplay.actions.Enter;
import org.openqa.selenium.Keys;

public class Wit {
    public static Enter the(Keys arrowDown) {
    }
}
