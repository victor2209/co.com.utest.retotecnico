package tasks;

import model.UtestDatos;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

import java.util.List;


public class llamarDireccion implements Task {


    public static void laPagina(List<UtestDatos> datos) {
    }


    @Override
    public <T extends Actor> void performAs(T actor) {


}
}

